//
//  ViewController.swift
//  Building Good Mathematicians
//
//  Created by Callum Koh on 24/8/17.
//  Copyright © 2017 pop("Goes the weasel"). All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func loginButton(_ sender: Any){
        performSegue(withIdentifier: "loggingIn", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

