//
//  Dashboard.swift
//  Building Good Mathematicians
//
//  Created by Callum Koh on 24/8/17.
//  Copyright © 2017 pop("Goes the weasel"). All rights reserved.
//

import UIKit
import Foundation

class Dashboard: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var dashboardTableView: UITableView!
    
    var data: [String] = ["Overview","Tasks","Assignments","Videos","Revision","Settings","Log out"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "dashboardTable") as! DashboardTableViewCell
        
        let text = data[indexPath.row]
        
        cell.label.text = text
        
        return cell
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
