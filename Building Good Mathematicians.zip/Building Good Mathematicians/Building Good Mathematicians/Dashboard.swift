//
//  Dashboard.swift
//  Building Good Mathematicians
//
//  Created by Callum Koh on 24/8/17.
//  Copyright © 2017 pop("Goes the weasel"). All rights reserved.
//

import UIKit
import Foundation

class Dashboard: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var dashboardTableView: UITableView!
    
    var data: [String] = ["Overview","Tasks","Assignments","Videos","Revision","Settings","Log out"]
    var links: [String] = ["overviewLink","tasksLink","assignmentsLink","videosLink","revisionLink","settingsLink","logoutLink"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = dashboardTableView.dequeueReusableCell(withIdentifier: "dashboardTable") as! DashboardTableViewCell
        
        let text = data[indexPath.row]
        
        cell.label.text = text
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // This line stops the table cell from appearing as selected.
        tableView.deselectRow(at: indexPath, animated: true)
        
        /*
         This code just allows alerts, uncomment this if you want, but I don't think you'll get anywhere with this.
         let alertController = UIAlertController(title: "Hint",message: "You have selected row \(indexPath.row)",preferredStyle: .alert)
         let alertAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
         
         alertController.addAction(alertAction)
         
         present(alertController, animated:true, completion:nil)*/
        
        
        // Getting into the viewController names - check the storyboard and select the added viewControllers. If you check the details in the third icon, you'll find that the storyboard IDs are the same as the ones in extras.
        let vcName = links[indexPath.row]
        
        // This creates the segues or links between the tableView and the viewControllers.
        let viewController = storyboard?.instantiateViewController(withIdentifier: vcName)
        
        // This initiates the viewController links.
        self.navigationController?.pushViewController(viewController!, animated: true)
        
    }
    
}
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


